package com.learning.sampleProject.repository;

import org.springframework.data.repository.CrudRepository;

import com.learning.sampleProject.entity.Product;

public interface ProductRepository extends CrudRepository<Product, Integer>{

}
