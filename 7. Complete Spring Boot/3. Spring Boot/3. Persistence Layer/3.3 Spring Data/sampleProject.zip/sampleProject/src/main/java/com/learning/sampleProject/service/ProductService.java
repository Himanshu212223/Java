package com.learning.sampleProject.service;

import java.util.List;

import com.learning.sampleProject.dto.ProductDTO;
import com.learning.sampleProject.entity.Product;

public interface ProductService {
	public void showProductDetail() ;
	public Integer createProduct(ProductDTO productDTO);
	public ProductDTO getProduct(Integer productID) ;
	public List<ProductDTO> getAllProducts();
	public void updateProductQuantity(Integer id, Integer quantity) throws Exception ;
	public void deleteProduct(Integer id) throws Exception ;
}
