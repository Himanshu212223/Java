package com.learning.sampleProject.dto;

import lombok.Data;

@Data
public class ProductDTO {
	private Integer productID ;
	private String name ;
	private Integer quantity;
	
	//	Default Constructor
	public ProductDTO() {}

	//	Parameterized Constructor
	public ProductDTO(Integer productID, String name, Integer quantity) {
		super();
		this.productID = productID;
		this.name = name;
		this.quantity = quantity;
	}
	
	
	
	public Integer getProductID() {
		return productID;
	}

	public void setProductID(Integer productID) {
		this.productID = productID;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Integer getQuantity() {
		return quantity;
	}

	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}

	@Override
	public String toString() {
		return this.productID + " " + this.name + " " + this.quantity ;
	}
	
}
