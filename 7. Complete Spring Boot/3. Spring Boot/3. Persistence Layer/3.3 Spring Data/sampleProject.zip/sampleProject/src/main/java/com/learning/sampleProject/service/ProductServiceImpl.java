package com.learning.sampleProject.service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.learning.sampleProject.dto.ProductDTO;
import com.learning.sampleProject.entity.Product;
import com.learning.sampleProject.repository.ProductRepository;

import jakarta.transaction.Transactional;



@Service
@Transactional
public class ProductServiceImpl implements ProductService{
	//	It is an Service Implementation class of ProductService Interface hence it is named as ProductServiceImpl
	
	private ModelMapper modelMapper = new ModelMapper();

	@Autowired
	private ProductRepository productRepository ;
	
	
	
	
	@Override
	public void showProductDetail() {
		System.out.println("Product Service Service is working fine.");
	}
	
	//	Method to CREATE Product.
	@Override
	public Integer createProduct(ProductDTO productDTO) {
		Product product = modelMapper.map(productDTO, Product.class) ;
		return productRepository.save(product).getProductID() ;
	}
	
	
	//	Method to READ Product.
	@Override
	public ProductDTO getProduct(Integer productID) {
		Optional<Product> optionalProduct = productRepository.findById(productID) ;
		Product product = optionalProduct.orElse(null) ;
		return modelMapper.map(product, ProductDTO.class) ;
	}
	
	
	//	Method to READ ALL Product.
	@Override
	public List<ProductDTO> getAllProducts(){
		List<Product> productList = (List<Product>) productRepository.findAll();
		
		List<ProductDTO> productDTOList = productList.stream().map(eachProduct -> modelMapper.map(eachProduct, ProductDTO.class)).collect(Collectors.toList()) ;
		
		return productDTOList ;
	}
	
	
	//	Method to UPDATE Product.
	@Override
	public void updateProductQuantity(Integer id, Integer quantity) throws Exception {
		Optional<Product> product = productRepository.findById(id) ;
		Product prod = product.orElseThrow(() -> new Exception("Product does not exist.") );
		prod.setQuantity(quantity);
	}
	
	
	//	Method to DELETE Product.
	@Override
	public void deleteProduct(Integer id) throws Exception {
		Optional<Product> product = productRepository.findById(id) ;
		product.orElseThrow(() -> new Exception("Product does not exist."));
		productRepository.deleteById(id);
	}
}
