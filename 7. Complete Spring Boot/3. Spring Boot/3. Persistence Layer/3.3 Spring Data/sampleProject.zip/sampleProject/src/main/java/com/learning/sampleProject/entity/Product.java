package com.learning.sampleProject.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Product {
	@Id
	private Integer productID ;
	@Column(name = "productName" )
	private String name ;
	private Integer quantity;
	
	//	Default Constructor
	public Product () {}

	//	Parameterized Constructor
	public Product(Integer productID, String name, Integer quantity) {
		super();
		this.productID = productID;
		this.name = name;
		this.quantity = quantity;
	}

	//	Below are Getter - Setters
	
	
	@Override
	public String toString() {
		return this.productID + " " + this.name + " " + this.quantity ;
	}

	public Integer getProductID() {
		return productID;
	}

	public void setProductID(Integer productID) {
		this.productID = productID;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Integer getQuantity() {
		return quantity;
	}

	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}
	
}
