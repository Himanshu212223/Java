package com.learning.sampleProject;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.learning.sampleProject.dto.ProductDTO;
import com.learning.sampleProject.entity.Product;
import com.learning.sampleProject.service.ProductService;

@SpringBootApplication
public class SampleProjectApplication implements CommandLineRunner{
	
	//	Soft Coupling the Service Layer Class here.
	@Autowired
	private ProductService productServiceImpl ;
	

	public static void main(String[] args) {
		SpringApplication.run(SampleProjectApplication.class, args);
	}


	@Override
	public void run(String... args) throws Exception {
		// TODO Auto-generated method stub
		
		ProductDTO productDTO = new ProductDTO(121, "Product_1", 43);
		ProductDTO productDTO1 = new ProductDTO(124, "Product_124", 67);
		
		
		//	Calling create method of Service layer
		Integer id1 = productServiceImpl.createProduct(productDTO) ;
		Integer id2 = productServiceImpl.createProduct(productDTO1) ;
		
		//	Calling read method of Service layer
		Integer tempInt = 121 ;
		ProductDTO productDTO2 = productServiceImpl.getProduct(tempInt) ;
		System.out.println(productDTO2);
		
		//	Calling read all method of Service layer
		List<ProductDTO> dtoList = productServiceImpl.getAllProducts() ;
		dtoList.forEach(item -> System.out.println(item));
		
		// Calling update method of Service layer
		Integer id = 121 ;
		Integer qty = 87 ;
		productServiceImpl.updateProductQuantity(id, qty);

		//	Calling delete method of Service layer
		productServiceImpl.deleteProduct(id);
	}

}
