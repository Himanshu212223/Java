package com.learning.sampleProject.service;

public interface ProductService {
	public void showProductDetail() ;
}
