package com.learning.sampleProject.repository;


import java.util.List;

import org.springframework.stereotype.Repository;

import com.learning.sampleProject.entity.Product;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.transaction.Transactional;


@Repository
@Transactional
public class ProductRepository {

	@PersistenceContext
	private EntityManager entityManager ;
	
	
	
	//	Defining Custom Methods to CREATE product.
	public String addProduct(Product product) {
		try {
			entityManager.persist(product);
			return "Successfully added the Product" ;
		}
		catch (Exception e){
			return e.getMessage();
		}
	}
	
	
	//	Defining Custom Methods to READ product.
	public Product getProduct(int id) {
		return entityManager.find(Product.class, id);
	}
	
	
	//	Defining Custom Methods to READ ALL product.
	public List<Product> getAllProduct() {
		String query = "SELECT p FROM Product p " ;
		List<Product> productList = entityManager.createQuery(query, Product.class).getResultList();
		return productList ;
	}
	
	
	//	Defining Custom Methods to UPDATE product.
	public Product updateProduct(Product product) {
		Product tempProduct = entityManager.find(Product.class, product.getProductID()) ;
		tempProduct.setName(product.getName());
		tempProduct.setQuantity(product.getQuantity());
		return entityManager.merge(tempProduct) ;
	}
	
	
	//	Defining Custom Method to DELETE product.
	public String deleteProduct(int id) {
		Product productToDelete = entityManager.find(Product.class, id) ;
		entityManager.remove(productToDelete);
		return "Deleted the Product." ;
	}
}
