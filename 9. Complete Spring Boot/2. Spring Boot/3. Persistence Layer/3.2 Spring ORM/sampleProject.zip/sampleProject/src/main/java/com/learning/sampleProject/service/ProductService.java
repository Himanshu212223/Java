package com.learning.sampleProject.service;

import java.util.List;

import com.learning.sampleProject.entity.Product;

public interface ProductService {
	public void showProductDetail() ;
	public String addProduct(Product product) ;
	public Product displayProduct(int id) ;
	public List<Product> displayAllProduct() ;
}
