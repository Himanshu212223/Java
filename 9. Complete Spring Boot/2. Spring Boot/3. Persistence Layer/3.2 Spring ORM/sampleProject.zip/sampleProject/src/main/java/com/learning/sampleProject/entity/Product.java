package com.learning.sampleProject.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Product {
	@Id
	private int productID ;
	@Column(name = "productName" )
	private String name ;
	private int quantity;
	
	//	Default Constructor
	public Product () {}

	//	Parameterized Constructor
	public Product(int productID, String name, int quantity) {
		super();
		this.productID = productID;
		this.name = name;
		this.quantity = quantity;
	}

	//	Below are Getter - Setters
	public int getProductID() {
		return productID;
	}

	public void setProductID(int productID) {
		this.productID = productID;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	
	@Override
	public String toString() {
		return this.productID + " " + this.name + " " + this.quantity ;
	}
	
}
