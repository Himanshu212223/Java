package com.learning.sampleProject;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.learning.sampleProject.entity.Product;
import com.learning.sampleProject.service.ProductService;

@SpringBootApplication
public class SampleProjectApplication implements CommandLineRunner{
	
	//	Soft Coupling the Service Layer Class here.
	@Autowired
	private ProductService productServiceImpl ;
	

	public static void main(String[] args) {
		SpringApplication.run(SampleProjectApplication.class, args);
	}


	@Override
	public void run(String... args) throws Exception {
		// TODO Auto-generated method stub
		productServiceImpl.showProductDetail();
		
//		Product sampleProduct = new Product(13, "SampleProduct", 6);
//		String createStatus = productServiceImpl.addProduct(sampleProduct) ;
//		System.out.println(createStatus);
		
		
		Product availableProduct = productServiceImpl.displayProduct(12) ;
		System.out.println(availableProduct);
	
		List<Product> productList = productServiceImpl.displayAllProduct() ;
		productList.forEach(item -> {System.out.println(item);});
	}

}
