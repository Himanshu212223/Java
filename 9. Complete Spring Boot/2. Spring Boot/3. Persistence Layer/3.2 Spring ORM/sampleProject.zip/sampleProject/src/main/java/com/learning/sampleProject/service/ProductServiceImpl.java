package com.learning.sampleProject.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.learning.sampleProject.entity.Product;
import com.learning.sampleProject.repository.ProductRepository;

@Service
public class ProductServiceImpl implements ProductService{
	//	It is an Service Implementation class of ProductService Interface hence it is named as ProductServiceImpl
	
	@Autowired
	private ProductRepository productRepository ;
	
	
	@Override
	public void showProductDetail() {
		System.out.println("Product Service Service is working fine.");
	}
	
	@Override
	public String addProduct(Product product) {
		String addProductStatus = productRepository.addProduct(product) ;
		return addProductStatus ;
	}
	
	@Override
	public Product displayProduct(int id) {
		Product product = productRepository.getProduct(id) ;
		return product ;
	}
	
	@Override
	public List<Product> displayAllProduct(){
		return productRepository.getAllProduct();
	}
}
